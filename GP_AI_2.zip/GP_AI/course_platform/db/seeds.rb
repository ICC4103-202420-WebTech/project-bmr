teacher1 = User.create(name: 'John Wick', role: 'teacher')
teacher2 = User.create(name: 'Papa Johns', role: 'teacher')

student1 = User.create(name: 'Xoro Jackson', role: 'student')
student2 = User.create(name: 'El Pepe', role: 'student')

# Create Courses and Lessons
course1 = teacher1.courses.create(title: 'Ruby on Rails', description: 'Learn the basics of Rails.')
course2 = teacher2.courses.create(title: 'JavaScript Basics', description: 'Introduction to JavaScript.')
course3 = teacher1.courses.create(title: 'HTML and CSS', description: 'Learn to build static websites.')
course4 = teacher2.courses.create(title: 'Python for Beginners', description: 'Intro to Python.')

# Create Lessons for each Course
4.times { |i| course1.lessons.create(title: "Lesson #{i + 1}", content: "Content of lesson #{i + 1}", lesson_type: 'lecture') }
4.times { |i| course2.lessons.create(title: "Lesson #{i + 1}", content: "Content of lesson #{i + 1}", lesson_type: 'lecture') }
4.times { |i| course3.lessons.create(title: "Lesson #{i + 1}", content: "Content of lesson #{i + 1}", lesson_type: 'lecture') }
4.times { |i| course4.lessons.create(title: "Lesson #{i + 1}", content: "Content of lesson #{i + 1}", lesson_type: 'lecture') }

# Create Enrollments for     Students
Enrollment.create(user: student1, course: course1, progress: 50)
Enrollment.create(user: student2, course: course2, progress: 75)
Enrollment.create(user: student1, course: course3, progress: 25)
Enrollment.create(user: student2, course: course4, progress: 100)
