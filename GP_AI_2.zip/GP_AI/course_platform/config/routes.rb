Rails.application.routes.draw do
  get "courses/index"
  get "courses/show"
  root to: 'home#index'
  resources :courses, only: [:index, :show]
end
