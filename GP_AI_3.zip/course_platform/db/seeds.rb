# Para que esté limpio al correr los seeds
User.delete_all


# Usuarios
teacher1 = User.create!(first_name: 'John', last_name: 'Wick', email: 'john.wick@example.com', role: 'teacher', password: 'password123')
teacher2 = User.create!(first_name: 'Papa', last_name: 'Johns', email: 'papa.johns@example.com', role: 'teacher', password: 'password123')

student1 = User.create!(first_name: 'Xoro', last_name: 'Jackson', email: 'xoro.jackson@example.com', role: 'student', password: 'password123')
student2 = User.create!(first_name: 'El', last_name: 'Pepe', email: 'el.pepe@example.com', role: 'student', password: 'password123')


# Crear Cursos y Lecciones
course1 = teacher1.courses.create(title: 'Ruby on Rails', description: 'Learn the basics of Rails.')
course2 = teacher2.courses.create(title: 'JavaScript Basics', description: 'Introduction to JavaScript.')
course3 = teacher1.courses.create(title: 'HTML and CSS', description: 'Learn to build static websites.')
course4 = teacher2.courses.create(title: 'Python for Beginners', description: 'Intro to Python.')

# Crear Lecciones para cada Curso
4.times { |i| course1.lessons.create(title: "Lesson #{i + 1}", content: "Content of lesson #{i + 1}", lesson_type: 'lecture') }
4.times { |i| course2.lessons.create(title: "Lesson #{i + 1}", content: "Content of lesson #{i + 1}", lesson_type: 'lecture') }
4.times { |i| course3.lessons.create(title: "Lesson #{i + 1}", content: "Content of lesson #{i + 1}", lesson_type: 'lecture') }
4.times { |i| course4.lessons.create(title: "Lesson #{i + 1}", content: "Content of lesson #{i + 1}", lesson_type: 'lecture') }

# Crear Inscripciones de Estudiantes en los Cursos
Enrollment.create(user: student1, course: course1, progress: 50)
Enrollment.create(user: student2, course: course2, progress: 75)
Enrollment.create(user: student1, course: course3, progress: 25)
Enrollment.create(user: student2, course: course4, progress: 100)

# Crear Preguntas para las Lecciones
question1 = course1.lessons.first.questions.create(content: 'What is Ruby?', user: student1)
question2 = course2.lessons.first.questions.create(content: 'What is JavaScript?', user: student2)
question3 = course3.lessons.first.questions.create(content: 'What is HTML?', user: student1)
question4 = course4.lessons.first.questions.create(content: 'What is Python?', user: student2)

# Crear Respuestas para las Preguntas
answer1 = question1.answers.create(content: 'Ruby is a programming language.', user: teacher1)
answer2 = question2.answers.create(content: 'JavaScript is a scripting language for web development.', user: teacher2)
answer3 = question3.answers.create(content: 'HTML is a markup language for creating web pages.', user: teacher1)
answer4 = question4.answers.create(content: 'Python is a versatile programming language.', user: teacher2)
