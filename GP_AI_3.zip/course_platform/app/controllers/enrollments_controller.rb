class EnrollmentsController < ApplicationController
    def create
      @course = Course.find(params[:course_id])
      @enrollment = @course.enrollments.build(user: current_user)
      if @enrollment.save
        flash[:success] = "You have been enrolled in the course!"
        redirect_to course_path(@course)
      else
        flash.now[:error] = "Error enrolling in the course"
        redirect_to course_path(@course)
      end
    end
  
    def destroy
      @enrollment = Enrollment.find(params[:id])
      @enrollment.destroy
      flash[:success] = "You have been unenrolled from the course"
      redirect_to courses_path
    end
  end
  