class AnswersController < ApplicationController
    def create
      @question = Question.find(params[:question_id])
      @answer = @question.answers.build(answer_params.merge(user: current_user))
      if @answer.save
        flash[:success] = "Answer posted successfully"
        redirect_to lesson_path(@question.lesson)
      else
        flash.now[:error] = "Error posting answer"
        render 'lessons/show'
      end
    end
  
    def update
      @answer = Answer.find(params[:id])
      if @answer.update(answer_params)
        flash[:success] = "Answer updated successfully"
        redirect_to lesson_path(@answer.question.lesson)
      else
        flash.now[:error] = "Error updating answer"
        render 'lessons/show'
      end
    end
  
    def destroy
      @answer = Answer.find(params[:id])
      lesson = @answer.question.lesson
      @answer.destroy
      flash[:success] = "Answer deleted successfully"
      redirect_to lesson_path(lesson)
    end
  
    private
  
    def answer_params
      params.require(:answer).permit(:content)
    end
  end
  