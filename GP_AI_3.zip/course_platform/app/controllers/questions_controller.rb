class QuestionsController < ApplicationController
    def create
      @lesson = Lesson.find(params[:lesson_id])
      @question = @lesson.questions.build(question_params)
      @question.user = current_user
      if @question.save
        flash[:success] = "Question posted successfully"
        redirect_to lesson_path(@lesson)
      else
        flash.now[:error] = "Error posting question"
        render 'lessons/show'
      end
    end
  
    def update
      @question = Question.find(params[:id])
      if @question.update(question_params)
        flash[:success] = "Question updated successfully"
        redirect_to lesson_path(@question.lesson)
      else
        flash.now[:error] = "Error updating question"
        render 'lessons/show'
      end
    end
  
    def destroy
      @question = Question.find(params[:id])
      @lesson = @question.lesson
      @question.destroy
      flash[:success] = "Question deleted successfully"
      redirect_to lesson_path(@lesson)
    end
  
    private
  
    def question_params
      params.require(:question).permit(:content)
    end
  end
  