class Lesson < ApplicationRecord
  belongs_to :course
  has_many :questions, dependent: :destroy

  # Integración de ActionText para contenido
  has_rich_text :content

  # Validaciones
  validates :title, presence: true
  validates :content, presence: true, unless: -> { video_url.present? }
  validates :video_url, presence: true, unless: -> { content.present? }

  # Asegurarse de que la URL del video es válida si está presente
  validates :video_url, format: { with: URI::regexp(%w[http https]), message: 'must be a valid URL' }, allow_blank: true
end
