class User < ApplicationRecord
  has_many :courses, foreign_key: :teacher_id
  has_many :enrollments
  has_many :enrolled_courses, through: :enrollments, source: :course
  has_many :questions
  has_many :answers

  validates :name, presence: true
  validates :email, presence: true, format: { with: URI::MailTo::EMAIL_REGEXP }
  validates :role, presence: true, inclusion: { in: %w[teacher student] }
end
