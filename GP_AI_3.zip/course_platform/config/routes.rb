Rails.application.routes.draw do
  root to: 'home#index'

  # Rutas CRUD completas para Courses y anidar Lessons
  resources :courses do
    resources :lessons do
      resources :questions, only: [:create, :edit, :update, :destroy]
    end
  end  

  # Añadir estas rutas para "About" y "Contact"
  get 'about', to: 'home#about'
  get 'contact', to: 'home#contact'

  # Rutas CRUD para Enrollments y Answers (mantener fuera de la anidación)
  resources :enrollments, only: [:create, :destroy]
  resources :answers, only: [:create, :update, :destroy]
end
