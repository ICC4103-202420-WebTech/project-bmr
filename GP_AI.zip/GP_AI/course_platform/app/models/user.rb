class User < ApplicationRecord
    has_many :courses, foreign_key: :teacher_id
    has_many :enrollments
    has_many :enrolled_courses, through: :enrollments, source: :course
    has_many :questions
    has_many :answers
  end
  