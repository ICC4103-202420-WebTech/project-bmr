# Creating users
teacher = User.create(name: 'Xoro Jackson', email: 'xoro@jackson.com', role: 'teacher')
student = User.create(name: 'El pelao', email: 'el@pelao.com', role: 'student')

# Creating a course
course = teacher.courses.create(title: 'Ruby on Rails', description: 'Learn Rails basics')

# Creating lessons
lesson1 = course.lessons.create(title: 'Introduction', content: 'Welcome to Ruby on Rails', lesson_type: 'lecture')
lesson2 = course.lessons.create(title: 'Models', content: 'Learn about Rails Models', lesson_type: 'lecture')

# Enrolling a student
Enrollment.create(user: student, course: course, progress: 50)

# Adding questions and answers
question = lesson1.questions.create(content: 'What is Rails?', user: student)
answer = question.answers.create(content: 'Rails is a web framework', user: teacher)
